import "./Services.css"
import Construction from "../../assests/image/icon_construction.png";
import Renovation from "../../assests/image/icon_renovation.png";
import consultation from "../../assests/image/icon_consultation.png";
import repair from "../../assests/image/icon_repair_services.png";
import architecture from "../../assests/image/icon_architecture.png";
import electricity from "../../assests/image/icon_electricity.png";

export default function Services() {
    return (
        <>
            <div className="container-fluid bgcolor">
                <div className="container">
                    <h1 className="text-center mt-2 mb-3">Services</h1>

                    <div class="row divsection">
                        <div className="col-lg-4    customService">
                            <img className="img1" src={Construction} alt="" />
                            <h3>Construction</h3>
                        </div>
                        <div className="col-lg-4  active1   customService">
                            <img className="img1" src={Renovation} alt="" />
                            <h3>Revolution</h3>
                        </div>
                        <div className="col-lg-4    customService">
                            <img className="img1" src={consultation} alt="" />
                            <h3>Consulation</h3>
                        </div>
                    </div>
                    <div class="row divsection">
                        <div className="col-lg-4  active1  customService">
                            <img className="img1" src={repair} alt="" />
                            <h3>Repair Services</h3>
                        </div>
                        <div className="col-lg-4    customService">
                            <img className="img1" src={architecture} alt="" />
                            <h3>Architecture</h3>
                        </div>
                        <div className="col-lg-4  active1   customService">
                            <img className="img1" src={electricity} alt="" />
                            <h3>Electric</h3>
                        </div>
                    </div>


                </div>
            </div>

        </>
    );
}
