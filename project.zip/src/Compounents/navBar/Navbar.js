import "./Navbar.css"
import logo from "../../assests/image/logo.png"
function Navbar() {
    return (
        <>
            <div className="container-fluid">
                <div className="row">
                   

                    <div className="col-12 ">
                        <nav className="navbar navbar-expand-lg navbar-light Hover-nav"  >
                            <div className="container">
                                <div className="d-flex">
                                    <img src={logo} alt="logo" />
                                    <a  className="navbar-brand textlogo d-flex mx-3" href="#"> <b>TheBOX</b> </a>

                                </div>
                                <div>
                                    <button className="navbar-toggler" type="button" data-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                        <span className="navbar-toggler-icon"></span>
                                    </button>
                                    <div className="collapse navbar-collapse mr-5 customcss" id="navbarSupportedContent">
                                        <ul className="navbar-nav pr-4  px-5 me-auto mb-2 mb-lg-0 ">
                                            <li className="nav-item">
                                                <a className="nav-link navBar  textheading" aria-current="page" href="#">Home</a>
                                            </li>
                                            <li className="nav-item">
                                                <a className="nav-link navBar textheading" href="#">About us</a>
                                            </li>
                                            <li className="nav-item">
                                                <a className="nav-link navBar textheading" href="#">Projects</a>
                                            </li>
                                            <li className="nav-item">
                                                <a className="nav-link navBar textheading" href="#">Services</a>
                                            </li>
                                            <li className="nav-item">
                                                <a className="nav-link navBar textheading" href="#">Contact Us</a>
                                            </li>


                                        </ul>

                                    </div>
                                </div>
                            </div>
                        </nav>
                    </div>



                </div>
            </div>


        </>
    );

}
export default Navbar;