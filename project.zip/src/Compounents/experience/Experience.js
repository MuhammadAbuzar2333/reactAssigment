import client from "../../assests/image/icon_happy_clients.png"
import project from "../../assests/image/icon_projects_completed.png"
import award from "../../assests/image/icon_award_wins.png"
import business from "../../assests/image/icon_business_years.png"


import "./Experience.css"
export default function Experience() {
    return (
        <>
            <div className="container">
                <div class="row">
                    <div className="col-lg-7 col-sm-12 mainrow">
                        <div className="exper   box1">
                            <img className="imag1" src={client} alt="" />
                            <h3>84</h3>
                            <p className="pcstm">Happy Client</p>
                        </div>
                        <div className="exper box2">
                            <img  className="imag2" src={project} alt="" />
                            <h3>123</h3>
                            <p className="pcstm">Projects Completed</p>
                        </div>
                        <div className="exper box3">
                            <img  className="imag3" src={award} alt="" />
                            <h3>37</h3>
                            <p className="pcstm">Awards Win</p>

                        </div>
                        <div className="exper box4">
                            <img  className="imag4" src={business} alt="" />
                            <h3>30</h3>
                            <p className="pcstm">Years in Business</p>
                        </div>

                    </div>

                    <div className="col-lg-5 col-sm-12 p-5 itemse">
                        <h2 className="textcolor">30 Years of <br />
                            Experience
                        </h2>
                        <p className="textcolor">Lorem ipsum dolor sit amet consectetur adipisicing elit. Esse neque eos dolor, et consectetur aliquam, pariatur voluptatem alias ducimus nisi, delectus voluptates mollitia. A
                            liquid reiciendis repellat odio eum. Aliquid, maxime.</p>
                        <button className="btn btn-primary  ">Contact Us</button>
                    </div>

                </div>
            </div>

        </>
    );
}
